from aiogram import Router, F, Bot
from aiogram.types import Message
from database import get_or_create_member, increment_messages
from utils.moderation import check_message
from utils.logger import log

router = Router()


@router.message(F.chat.type.in_({"group", "supergroup"}))
async def handle_group_message(message: Message, bot: Bot, group=None, is_spam: bool = False):
    """Main handler for all group messages — runs moderation checks."""
    if not message.from_user or message.from_user.is_bot:
        return

    if not group:
        return

    # Track member
    await get_or_create_member(
        user_id=message.from_user.id,
        group_id=message.chat.id,
        username=message.from_user.username,
        full_name=message.from_user.full_name,
    )

    # Run moderation
    deleted = await check_message(bot, message, group, is_spam=is_spam)

    # If not deleted — count the message
    if not deleted:
        await increment_messages(message.from_user.id, message.chat.id)
