from aiogram import Router, Bot, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import Command, CommandStart
from keyboards.inline import (
    main_menu_kb, settings_menu_kb, stats_menu_kb,
    protection_settings_kb, moderation_settings_kb,
    language_kb, pip_shop_kb, back_kb,
)
from database import (
    get_or_create_group, update_group,
    get_or_create_member, update_member,
    get_violations_stats, get_total_violations, get_violations_today,
    get_top_violators, get_top_active, get_top_reputation,
)
from filters.admin import IsAdminFilter
from utils.logger import log
import csv
import io

router = Router()

PIPBOT_LOGO = "🐍"

MAIN_MENU_TEXT = (
    f"{PIPBOT_LOGO} <b>PipBot — Умный модератор</b>\n\n"
    "Выбери раздел в меню ниже:"
)

HELP_TEXT = """
📖 <b>Инструкция по PipBot</b>

<b>Команды для всех:</b>
/start — главное меню
/help — помощь
/rules — правила группы
/report — пожаловаться на сообщение
/myprofile — мой профиль и статистика
/shop — магазин Pips

<b>Команды для администраторов:</b>
/warn — предупредить пользователя (ответом)
/unwarn — снять предупреждение (ответом)
/mute [время] — замутить (пример: /mute 30m)
/unmute — размутить (ответом)
/ban — заблокировать (ответом)
/unban — разблокировать (ответом)
/stats — статистика группы
/logs — последние действия
/settings — настройки группы

<b>Система Pips 💰:</b>
Зарабатывай Pips за активность и трать их в /shop!
• 🛡️ PipShield — защита от одного мута (50 Pips)
• ⭐ +1 Репутация (30 Pips)

<b>Система репутации ⭐:</b>
Репутация растёт за активность (каждые 10 сообщений) и падает за нарушения.
"""

INFO_TEXT = (
    f"{PIPBOT_LOGO} <b>О боте PipBot</b>\n\n"
    "Версия: <b>1.0.0</b>\n"
    "Библиотека: <b>aiogram 3.x</b>\n"
    "База данных: <b>SQLite / PostgreSQL</b>\n\n"
    "<b>Слоган:</b> 🛡️ <i>Чистота в чате — наша работа</i>\n\n"
    "Разработано для конкуренции с Group Help и ChatKeeperBot.\n"
    "Добавь меня в группу и дай права администратора!"
)

SUPPORT_TEXT = (
    "🆘 <b>Поддержка PipBot</b>\n\n"
    "Если у тебя возникли проблемы:\n"
    "• Проверь, что у бота есть права администратора\n"
    "• Используй /settings для настройки\n"
    "• Убедись, что бот не ограничен другим ботом\n\n"
    "📬 Для связи с разработчиком: @your_support_username"
)


@router.message(CommandStart())
async def cmd_start(message: Message):
    await message.answer(MAIN_MENU_TEXT, parse_mode="HTML", reply_markup=main_menu_kb())


@router.message(Command("help"))
async def cmd_help(message: Message):
    await message.answer(HELP_TEXT, parse_mode="HTML")


@router.message(Command("settings"), IsAdminFilter())
async def cmd_settings(message: Message, group=None):
    if not group:
        return await message.reply("❌ Команда только для групп.")
    await message.answer("⚙️ <b>Настройки группы</b>", parse_mode="HTML", reply_markup=settings_menu_kb())


@router.message(Command("shop"))
async def cmd_shop(message: Message, group=None):
    if not group:
        return await message.reply("❌ Команда только для групп.")
    member = await get_or_create_member(message.from_user.id, message.chat.id)
    await message.reply(
        f"🛒 <b>Магазин Pips</b>\n\nТвой баланс: <b>💰 {member.pips} Pips</b>",
        parse_mode="HTML",
        reply_markup=pip_shop_kb()
    )


# ===== MENU CALLBACKS =====

@router.callback_query(F.data == "menu_back")
async def cb_menu_back(callback: CallbackQuery):
    await callback.message.edit_text(MAIN_MENU_TEXT, parse_mode="HTML", reply_markup=main_menu_kb())
    await callback.answer()


@router.callback_query(F.data == "menu_help")
async def cb_menu_help(callback: CallbackQuery):
    await callback.message.edit_text(HELP_TEXT, parse_mode="HTML", reply_markup=back_kb())
    await callback.answer()


@router.callback_query(F.data == "menu_settings")
async def cb_menu_settings(callback: CallbackQuery, bot: Bot):
    # Check if admin
    try:
        m = await bot.get_chat_member(callback.message.chat.id, callback.from_user.id)
        if m.status not in ("creator", "administrator"):
            return await callback.answer("❌ Только для администраторов!", show_alert=True)
    except Exception:
        pass
    await callback.message.edit_text("⚙️ <b>Настройки группы</b>", parse_mode="HTML",
                                     reply_markup=settings_menu_kb())
    await callback.answer()


@router.callback_query(F.data == "menu_stats")
async def cb_menu_stats(callback: CallbackQuery):
    await callback.message.edit_text("📊 <b>Статистика</b>", parse_mode="HTML", reply_markup=stats_menu_kb())
    await callback.answer()


@router.callback_query(F.data == "menu_support")
async def cb_menu_support(callback: CallbackQuery):
    await callback.message.edit_text(SUPPORT_TEXT, parse_mode="HTML", reply_markup=back_kb())
    await callback.answer()


@router.callback_query(F.data == "menu_info")
async def cb_menu_info(callback: CallbackQuery):
    await callback.message.edit_text(INFO_TEXT, parse_mode="HTML", reply_markup=back_kb())
    await callback.answer()


@router.callback_query(F.data == "menu_language")
async def cb_menu_language(callback: CallbackQuery):
    await callback.message.edit_text("🌐 Выбери язык:", reply_markup=language_kb())
    await callback.answer()


@router.callback_query(F.data.startswith("lang_"))
async def cb_set_language(callback: CallbackQuery, group=None):
    lang = callback.data.split("_")[1]
    if group:
        await update_group(group.id, language=lang)
    lang_names = {"ru": "🇷🇺 Русский", "uk": "🇺🇦 Українська", "en": "🇬🇧 English", "kz": "🇰🇿 Қазақша"}
    await callback.answer(f"✅ Язык изменён на {lang_names.get(lang, lang)}", show_alert=True)
    await callback.message.edit_text(MAIN_MENU_TEXT, parse_mode="HTML", reply_markup=main_menu_kb())


# ===== SETTINGS CALLBACKS =====

@router.callback_query(F.data == "settings_protection")
async def cb_settings_protection(callback: CallbackQuery, group=None):
    if not group:
        return await callback.answer("❌ Только для групп", show_alert=True)
    await callback.message.edit_text(
        "🛡️ <b>Настройки защиты</b>\n\nВключи или выключи нужные фильтры:",
        parse_mode="HTML",
        reply_markup=protection_settings_kb(group)
    )
    await callback.answer()


@router.callback_query(F.data == "settings_moderation")
async def cb_settings_moderation(callback: CallbackQuery, group=None):
    if not group:
        return await callback.answer("❌ Только для групп", show_alert=True)
    await callback.message.edit_text(
        "👮 <b>Настройки модерации</b>",
        parse_mode="HTML",
        reply_markup=moderation_settings_kb(group)
    )
    await callback.answer()


# Protection toggles
TOGGLE_MAP = {
    "toggle_anti_swear": ("anti_swear_enabled", "Антимат"),
    "toggle_anti_spam": ("anti_spam_enabled", "Антиспам"),
    "toggle_anti_links": ("anti_links_enabled", "Антиссылки"),
    "toggle_anti_caps": ("anti_caps_enabled", "Антикапс"),
    "toggle_anti_mentions": ("anti_mentions_enabled", "Антиупоминания"),
    "toggle_anti_emoji": ("anti_emoji_enabled", "Антиэмодзи"),
    "toggle_account_age": ("check_account_age", "Проверка возраста"),
    "toggle_avatar_check": ("check_avatar", "Проверка аватара"),
}


@router.callback_query(F.data.in_(TOGGLE_MAP.keys()))
async def cb_toggle_protection(callback: CallbackQuery, group=None):
    if not group:
        return await callback.answer("❌ Только для групп", show_alert=True)

    field, label = TOGGLE_MAP[callback.data]
    current = getattr(group, field, False)
    new_val = not current
    await update_group(group.id, **{field: new_val})

    # Reload group for fresh keyboard
    from database import get_group
    group = await get_group(group.id)

    status = "включён ✅" if new_val else "выключен ❌"
    await callback.answer(f"{label} {status}", show_alert=False)

    # Refresh keyboard
    if callback.data in ("toggle_account_age", "toggle_avatar_check"):
        await callback.message.edit_reply_markup(reply_markup=moderation_settings_kb(group))
    else:
        await callback.message.edit_reply_markup(reply_markup=protection_settings_kb(group))


@router.callback_query(F.data == "toggle_warn_action")
async def cb_toggle_warn_action(callback: CallbackQuery, group=None):
    if not group:
        return await callback.answer("❌ Только для групп", show_alert=True)
    new_action = "ban" if group.warn_action == "mute" else "mute"
    await update_group(group.id, warn_action=new_action)
    from database import get_group
    group = await get_group(group.id)
    await callback.answer(f"Действие изменено на: {'Бан' if new_action == 'ban' else 'Мут'}")
    await callback.message.edit_reply_markup(reply_markup=moderation_settings_kb(group))


# ===== STATS CALLBACKS =====

@router.callback_query(F.data == "stats_violations")
async def cb_stats_violations(callback: CallbackQuery, group=None):
    if not group:
        return await callback.answer("❌ Только для групп", show_alert=True)

    stats = await get_violations_stats(group.id)
    total = await get_total_violations(group.id)
    today = await get_violations_today(group.id)

    type_icons = {
        "swear": "🤬", "spam": "🔁", "links": "🔗",
        "caps": "📢", "mentions": "👥", "emoji": "😀",
    }
    lines = [f"📊 <b>Статистика нарушений</b>\n",
             f"Сегодня: <b>{today}</b> | Всего: <b>{total}</b>\n"]
    for vtype, count in sorted(stats.items(), key=lambda x: -x[1]):
        icon = type_icons.get(vtype, "▪️")
        lines.append(f"{icon} {vtype}: {count}")

    if not stats:
        lines.append("Нарушений пока нет 🎉")

    await callback.message.edit_text(
        "\n".join(lines), parse_mode="HTML",
        reply_markup=back_kb("menu_stats")
    )
    await callback.answer()


@router.callback_query(F.data == "stats_violators")
async def cb_stats_violators(callback: CallbackQuery, group=None):
    if not group:
        return await callback.answer("❌ Только для групп", show_alert=True)

    top = await get_top_violators(group.id, limit=10)
    lines = ["👑 <b>Топ нарушителей</b>\n"]
    medals = ["🥇", "🥈", "🥉"] + ["▪️"] * 10

    for i, m in enumerate(top):
        name = m.full_name or m.username or f"User{m.user_id}"
        lines.append(f"{medals[i]} {name} — {m.violations_count} нарушений")

    if not top:
        lines.append("Нарушителей нет 🎉")

    await callback.message.edit_text(
        "\n".join(lines), parse_mode="HTML",
        reply_markup=back_kb("menu_stats")
    )
    await callback.answer()


@router.callback_query(F.data == "stats_active")
async def cb_stats_active(callback: CallbackQuery, group=None):
    if not group:
        return await callback.answer("❌ Только для групп", show_alert=True)

    top = await get_top_active(group.id, limit=10)
    lines = ["🏆 <b>Топ активных участников</b>\n"]
    medals = ["🥇", "🥈", "🥉"] + ["▪️"] * 10

    for i, m in enumerate(top):
        name = m.full_name or m.username or f"User{m.user_id}"
        lines.append(f"{medals[i]} {name} — {m.messages_count} сообщений")

    if not top:
        lines.append("Статистика пуста.")

    await callback.message.edit_text(
        "\n".join(lines), parse_mode="HTML",
        reply_markup=back_kb("menu_stats")
    )
    await callback.answer()


@router.callback_query(F.data == "stats_reputation")
async def cb_stats_reputation(callback: CallbackQuery, group=None):
    if not group:
        return await callback.answer("❌ Только для групп", show_alert=True)

    top = await get_top_reputation(group.id, limit=10)
    lines = ["⭐ <b>Топ по репутации</b>\n"]
    medals = ["🥇", "🥈", "🥉"] + ["▪️"] * 10

    for i, m in enumerate(top):
        name = m.full_name or m.username or f"User{m.user_id}"
        lines.append(f"{medals[i]} {name} — {m.reputation} ⭐")

    if not top:
        lines.append("Статистика пуста.")

    await callback.message.edit_text(
        "\n".join(lines), parse_mode="HTML",
        reply_markup=back_kb("menu_stats")
    )
    await callback.answer()


@router.callback_query(F.data == "stats_export")
async def cb_stats_export(callback: CallbackQuery, bot: Bot, group=None):
    if not group:
        return await callback.answer("❌ Только для групп", show_alert=True)

    members = await get_top_active(group.id, limit=1000)
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["user_id", "username", "full_name", "messages", "violations", "warnings", "reputation", "pips"])
    for m in members:
        writer.writerow([m.user_id, m.username or "", m.full_name or "",
                         m.messages_count, m.violations_count, m.warnings, m.reputation, m.pips])

    output.seek(0)
    from aiogram.types import BufferedInputFile
    file = BufferedInputFile(output.read().encode("utf-8"), filename=f"stats_{group.id}.csv")
    await bot.send_document(callback.from_user.id, file, caption=f"📁 Статистика группы {group.title}")
    await callback.answer("✅ Файл отправлен в личку!", show_alert=True)


# ===== SHOP CALLBACKS =====

@router.callback_query(F.data == "shop_shield")
async def cb_shop_shield(callback: CallbackQuery, group=None):
    if not group:
        return await callback.answer("❌ Только для групп", show_alert=True)

    member = await get_or_create_member(callback.from_user.id, group.id)
    if member.pip_shield_active:
        return await callback.answer("🛡️ Щит уже активен!", show_alert=True)
    if member.pips < 50:
        return await callback.answer(f"❌ Недостаточно Pips! У тебя {member.pips}/50", show_alert=True)

    await update_member(callback.from_user.id, group.id,
                        pips=member.pips - 50, pip_shield_active=True)
    await callback.answer("🛡️ PipShield активирован! Защищает от следующего мута.", show_alert=True)


@router.callback_query(F.data == "shop_rep")
async def cb_shop_rep(callback: CallbackQuery, group=None):
    if not group:
        return await callback.answer("❌ Только для групп", show_alert=True)

    member = await get_or_create_member(callback.from_user.id, group.id)
    if member.pips < 30:
        return await callback.answer(f"❌ Недостаточно Pips! У тебя {member.pips}/30", show_alert=True)

    await update_member(callback.from_user.id, group.id,
                        pips=member.pips - 30, reputation=member.reputation + 1)
    await callback.answer("⭐ +1 к репутации! Потрачено 30 Pips.", show_alert=True)


# ===== REPORT ACTIONS =====

@router.callback_query(F.data.startswith("report_"))
async def cb_report_action(callback: CallbackQuery, bot: Bot):
    parts = callback.data.split("_")
    action = parts[1]  # warn, mute, ban, dismiss
    user_id = int(parts[2])
    msg_id = int(parts[3]) if len(parts) > 3 else 0

    if action == "dismiss":
        await callback.message.edit_text("❌ Жалоба отклонена.")
        return await callback.answer()

    chat_id = callback.message.chat.id

    if action == "warn":
        from database import get_or_create_member, add_warning
        await get_or_create_member(user_id, chat_id)
        warnings = await add_warning(user_id, chat_id)
        await callback.answer(f"✅ Выдано предупреждение ({warnings})", show_alert=True)

    elif action == "mute":
        from utils.moderation import apply_mute
        await apply_mute(bot, chat_id, user_id, None, duration=3600)
        await callback.answer("✅ Пользователь замучен на 1 час", show_alert=True)

    elif action == "ban":
        await apply_ban(bot, chat_id, user_id)
        await callback.answer("✅ Пользователь заблокирован", show_alert=True)

    await callback.message.edit_text(
        callback.message.text + f"\n\n✅ Действие: {action.upper()} от {callback.from_user.full_name}"
    )
