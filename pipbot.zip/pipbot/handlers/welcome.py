import random
import asyncio
from aiogram import Router, Bot, F
from aiogram.types import Message, CallbackQuery, ChatPermissions
from aiogram.filters import ChatMemberUpdatedFilter, JOINED, LEFT, KICKED
from aiogram.types import ChatMemberUpdated
from database import (
    get_or_create_member, update_member,
    create_captcha, get_captcha, solve_captcha,
    add_mod_log,
)
from utils.moderation import apply_ban
from utils.logger import log
from keyboards.inline import captcha_kb

router = Router()


def _generate_math_captcha():
    """Return (question_str, answer_str, wrong_answers_list)."""
    a = random.randint(1, 20)
    b = random.randint(1, 20)
    op = random.choice(["+", "-", "*"])
    if op == "+":
        answer = a + b
    elif op == "-":
        answer = a - b
        if answer < 0:
            a, b = b, a
            answer = a - b
    else:
        a = random.randint(1, 10)
        b = random.randint(1, 10)
        answer = a * b

    question = f"{a} {op} {b} = ?"
    wrong = set()
    while len(wrong) < 3:
        w = answer + random.randint(-5, 5)
        if w != answer:
            wrong.add(w)
    return question, str(answer), [str(w) for w in wrong]


@router.chat_member(ChatMemberUpdatedFilter(JOINED))
async def on_member_joined(event: ChatMemberUpdated, bot: Bot, group=None):
    """Handle new member joining."""
    if not group:
        return

    user = event.new_chat_member.user

    # Skip if it's a bot (unless we want to greet bots separately)
    if user.is_bot:
        if group.welcome_enabled:
            await bot.send_message(
                event.chat.id,
                f"🤖 Бот {user.mention_html()} добавлен в группу.\n"
                f"<b>⚠️ Владельцы ботов несут ответственность за их действия.</b>",
                parse_mode="HTML"
            )
        return

    # Register member
    await get_or_create_member(
        user_id=user.id,
        group_id=event.chat.id,
        username=user.username,
        full_name=user.full_name,
    )

    # Captcha check
    if group.captcha_enabled:
        # Restrict until solved
        try:
            await bot.restrict_chat_member(
                chat_id=event.chat.id,
                user_id=user.id,
                permissions=ChatPermissions(can_send_messages=False),
            )
        except Exception as e:
            log.warning(f"Could not restrict new user {user.id}: {e}")

        question, answer, wrongs = _generate_math_captcha()
        kb = captcha_kb(answer, wrongs)

        sent = await bot.send_message(
            event.chat.id,
            f"👋 Привет, {user.mention_html()}!\n"
            f"Для доступа в чат реши пример:\n\n"
            f"<b>🧮 {question}</b>\n\n"
            f"У тебя <b>{group.captcha_timeout} секунд</b>.",
            parse_mode="HTML",
            reply_markup=kb,
        )

        await create_captcha(
            group_id=event.chat.id,
            user_id=user.id,
            answer=answer,
            message_id=sent.message_id,
            timeout=group.captcha_timeout,
        )

        # Schedule kick if not solved in time
        asyncio.create_task(
            _captcha_timeout(bot, event.chat.id, user.id, sent.message_id, group.captcha_timeout)
        )
        return

    # Welcome message (no captcha)
    if group.welcome_enabled:
        welcome_text = group.welcome_text.replace("{name}", user.mention_html())
        await bot.send_message(event.chat.id, welcome_text, parse_mode="HTML")


@router.chat_member(ChatMemberUpdatedFilter(LEFT | KICKED))
async def on_member_left(event: ChatMemberUpdated, bot: Bot, group=None):
    """Handle member leaving."""
    if not group or not group.farewell_enabled:
        return

    user = event.old_chat_member.user
    if user.is_bot:
        return

    farewell_text = group.farewell_text.replace("{name}", user.mention_html())
    try:
        await bot.send_message(event.chat.id, farewell_text, parse_mode="HTML")
    except Exception as e:
        log.warning(f"Could not send farewell: {e}")


@router.callback_query(F.data.startswith("captcha_"))
async def on_captcha_answer(callback: CallbackQuery, bot: Bot, group=None):
    """Handle captcha button press."""
    answer = callback.data.split("_", 1)[1]
    user = callback.from_user
    chat_id = callback.message.chat.id

    captcha = await get_captcha(group_id=chat_id, user_id=user.id)

    if not captcha:
        await callback.answer("⏰ Время вышло или капча уже решена.", show_alert=True)
        return

    if answer == captcha.answer:
        await solve_captcha(chat_id, user.id)
        # Restore permissions
        try:
            await bot.restrict_chat_member(
                chat_id=chat_id,
                user_id=user.id,
                permissions=ChatPermissions(
                    can_send_messages=True,
                    can_send_media_messages=True,
                    can_send_other_messages=True,
                    can_add_web_page_previews=True,
                ),
            )
        except Exception as e:
            log.warning(f"Could not restore permissions for {user.id}: {e}")

        try:
            await callback.message.delete()
        except Exception:
            pass

        if group and group.welcome_enabled:
            welcome_text = group.welcome_text.replace("{name}", user.mention_html())
            await bot.send_message(chat_id, welcome_text, parse_mode="HTML")

        await callback.answer("✅ Капча пройдена!", show_alert=False)
    else:
        await callback.answer("❌ Неверный ответ! Попробуй ещё раз.", show_alert=True)


async def _captcha_timeout(bot: Bot, chat_id: int, user_id: int, msg_id: int, timeout: int):
    """Kick the user if captcha is not solved within timeout."""
    await asyncio.sleep(timeout)
    captcha = await get_captcha(group_id=chat_id, user_id=user_id)
    if captcha and not captcha.solved:
        try:
            await bot.ban_chat_member(chat_id, user_id)
            await asyncio.sleep(2)
            await bot.unban_chat_member(chat_id, user_id)
        except Exception as e:
            log.warning(f"Could not kick {user_id} after captcha timeout: {e}")
        try:
            await bot.delete_message(chat_id, msg_id)
        except Exception:
            pass
        try:
            sent = await bot.send_message(
                chat_id,
                f"⏰ Пользователь не прошёл капчу и был удалён из группы."
            )
            await asyncio.sleep(10)
            await bot.delete_message(chat_id, sent.message_id)
        except Exception:
            pass
