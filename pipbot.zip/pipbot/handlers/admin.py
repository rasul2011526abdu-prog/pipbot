from datetime import datetime, timedelta
from aiogram import Router, Bot, F
from aiogram.types import Message
from aiogram.filters import Command
from database import (
    get_or_create_member, update_member,
    add_warning, remove_warning, add_mod_log,
    get_recent_logs, get_violations_stats,
    get_top_violators, get_top_active,
)
from utils.moderation import apply_mute, apply_unmute, apply_ban, apply_unban, send_to_log_chat
from utils.helpers import parse_duration, format_duration, user_mention
from filters.admin import IsAdminFilter
from utils.logger import log

router = Router()


def _parse_target(message: Message):
    """Extract target user from reply or @mention."""
    if message.reply_to_message and message.reply_to_message.from_user:
        u = message.reply_to_message.from_user
        return u.id, u.full_name
    # Try parsing from command args
    parts = message.text.split() if message.text else []
    for part in parts[1:]:
        if part.startswith("@"):
            return None, part  # can't get ID from @mention without extra API call
    return None, None


@router.message(Command("warn"), IsAdminFilter())
async def cmd_warn(message: Message, bot: Bot, group=None):
    if not group:
        return await message.reply("❌ Команда только для групп.")

    if not message.reply_to_message:
        return await message.reply("❌ Ответь на сообщение пользователя командой /warn [причина]")

    target = message.reply_to_message.from_user
    parts = message.text.split(maxsplit=1)
    reason = parts[1] if len(parts) > 1 else "нарушение правил"

    # Don't warn admins
    try:
        m = await bot.get_chat_member(message.chat.id, target.id)
        if m.status in ("creator", "administrator"):
            return await message.reply("❌ Нельзя предупреждать администратора.")
    except Exception:
        pass

    await get_or_create_member(target.id, message.chat.id)
    warnings = await add_warning(target.id, message.chat.id)

    await add_mod_log(
        group_id=message.chat.id,
        admin_id=message.from_user.id,
        admin_name=message.from_user.full_name,
        action="warn",
        target_id=target.id,
        target_name=target.full_name,
        reason=reason,
    )

    text = (
        f"⚠️ {user_mention(target)} получил предупреждение!\n"
        f"Причина: {reason}\n"
        f"Предупреждений: {warnings}/{group.max_warnings}"
    )
    await message.reply(text, parse_mode="Markdown")

    if warnings >= group.max_warnings:
        if group.warn_action == "ban":
            await apply_ban(bot, message.chat.id, target.id, group, reason="Превышен лимит")
            await message.answer(f"🚫 {user_mention(target)} заблокирован (превышен лимит).", parse_mode="Markdown")
        else:
            await apply_mute(bot, message.chat.id, target.id, group,
                             duration=group.mute_duration, reason="Превышен лимит")
            await message.answer(
                f"🔇 {user_mention(target)} замучен на {format_duration(group.mute_duration)} (превышен лимит).",
                parse_mode="Markdown"
            )
        await update_member(target.id, message.chat.id, warnings=0)


@router.message(Command("unwarn"), IsAdminFilter())
async def cmd_unwarn(message: Message, bot: Bot, group=None):
    if not group:
        return
    if not message.reply_to_message:
        return await message.reply("❌ Ответь на сообщение пользователя.")

    target = message.reply_to_message.from_user
    warnings = await remove_warning(target.id, message.chat.id)

    await add_mod_log(
        group_id=message.chat.id,
        admin_id=message.from_user.id,
        admin_name=message.from_user.full_name,
        action="unwarn",
        target_id=target.id,
        target_name=target.full_name,
    )

    await message.reply(
        f"✅ Снято предупреждение с {user_mention(target)}.\n"
        f"Осталось предупреждений: {warnings}/{group.max_warnings}",
        parse_mode="Markdown"
    )


@router.message(Command("mute"), IsAdminFilter())
async def cmd_mute(message: Message, bot: Bot, group=None):
    if not group:
        return
    if not message.reply_to_message:
        return await message.reply("❌ Ответь на сообщение. Пример: /mute 30m причина")

    target = message.reply_to_message.from_user
    parts = (message.text or "").split()
    duration = 3600
    reason = "без причины"

    if len(parts) >= 2:
        parsed = parse_duration(parts[1])
        if parsed:
            duration = parsed
            reason = " ".join(parts[2:]) if len(parts) > 2 else reason
        else:
            reason = " ".join(parts[1:])

    await apply_mute(bot, message.chat.id, target.id, group, duration=duration, reason=reason)
    await add_mod_log(
        group_id=message.chat.id,
        admin_id=message.from_user.id,
        admin_name=message.from_user.full_name,
        action="mute",
        target_id=target.id,
        target_name=target.full_name,
        reason=reason,
    )

    await message.reply(
        f"🔇 {user_mention(target)} замучен на {format_duration(duration)}.\nПричина: {reason}",
        parse_mode="Markdown"
    )
    await send_to_log_chat(bot, group,
                           f"🔇 Мут: {user_mention(target)} на {format_duration(duration)}. Причина: {reason}")


@router.message(Command("unmute"), IsAdminFilter())
async def cmd_unmute(message: Message, bot: Bot, group=None):
    if not group:
        return
    if not message.reply_to_message:
        return await message.reply("❌ Ответь на сообщение пользователя.")

    target = message.reply_to_message.from_user
    await apply_unmute(bot, message.chat.id, target.id)
    await add_mod_log(
        group_id=message.chat.id,
        admin_id=message.from_user.id,
        admin_name=message.from_user.full_name,
        action="unmute",
        target_id=target.id,
        target_name=target.full_name,
    )
    await message.reply(f"✅ {user_mention(target)} размучен.", parse_mode="Markdown")


@router.message(Command("ban"), IsAdminFilter())
async def cmd_ban(message: Message, bot: Bot, group=None):
    if not group:
        return
    if not message.reply_to_message:
        return await message.reply("❌ Ответь на сообщение пользователя.")

    target = message.reply_to_message.from_user
    parts = (message.text or "").split(maxsplit=1)
    reason = parts[1] if len(parts) > 1 else "без причины"

    await apply_ban(bot, message.chat.id, target.id, group, reason=reason)
    await add_mod_log(
        group_id=message.chat.id,
        admin_id=message.from_user.id,
        admin_name=message.from_user.full_name,
        action="ban",
        target_id=target.id,
        target_name=target.full_name,
        reason=reason,
    )
    await message.reply(
        f"🚫 {user_mention(target)} заблокирован.\nПричина: {reason}",
        parse_mode="Markdown"
    )
    await send_to_log_chat(bot, group, f"🚫 Бан: {user_mention(target)}. Причина: {reason}")


@router.message(Command("unban"), IsAdminFilter())
async def cmd_unban(message: Message, bot: Bot, group=None):
    if not group:
        return
    if not message.reply_to_message:
        return await message.reply("❌ Ответь на сообщение пользователя.")

    target = message.reply_to_message.from_user
    await apply_unban(bot, message.chat.id, target.id)
    await add_mod_log(
        group_id=message.chat.id,
        admin_id=message.from_user.id,
        admin_name=message.from_user.full_name,
        action="unban",
        target_id=target.id,
        target_name=target.full_name,
    )
    await message.reply(f"✅ {user_mention(target)} разбанен.", parse_mode="Markdown")


@router.message(Command("stats"), IsAdminFilter())
async def cmd_stats(message: Message, bot: Bot, group=None):
    if not group:
        return

    from database import get_violations_stats, get_total_violations, get_violations_today
    stats = await get_violations_stats(message.chat.id)
    total = await get_total_violations(message.chat.id)
    today = await get_violations_today(message.chat.id)

    type_icons = {
        "swear": "🤬", "spam": "🔁", "links": "🔗",
        "caps": "📢", "mentions": "👥", "emoji": "😀",
    }

    lines = [f"📊 <b>Статистика группы {message.chat.title}</b>\n"]
    lines.append(f"Нарушений сегодня: <b>{today}</b>")
    lines.append(f"Всего нарушений: <b>{total}</b>\n")
    lines.append("<b>По типам:</b>")
    for vtype, count in sorted(stats.items(), key=lambda x: -x[1]):
        icon = type_icons.get(vtype, "▪️")
        lines.append(f"{icon} {vtype}: {count}")

    await message.reply("\n".join(lines), parse_mode="HTML")


@router.message(Command("logs"), IsAdminFilter())
async def cmd_logs(message: Message, bot: Bot, group=None):
    if not group:
        return

    logs = await get_recent_logs(message.chat.id, limit=15)
    if not logs:
        return await message.reply("📝 Логи пусты.")

    lines = ["📝 <b>Последние действия модерации:</b>\n"]
    for log_entry in logs:
        dt = log_entry.created_at.strftime("%d.%m %H:%M")
        target = log_entry.target_name or str(log_entry.target_id)
        admin = log_entry.admin_name or str(log_entry.admin_id)
        reason = f" | {log_entry.reason}" if log_entry.reason else ""
        lines.append(
            f"[{dt}] <b>{log_entry.action.upper()}</b> → {target} | by {admin}{reason}"
        )

    await message.reply("\n".join(lines), parse_mode="HTML")


@router.message(Command("rules"))
async def cmd_rules(message: Message, group=None):
    if not group:
        return await message.reply("❌ Команда только для групп.")
    await message.reply(
        f"📋 <b>Правила группы {message.chat.title}:</b>\n\n{group.rules_text}",
        parse_mode="HTML"
    )


@router.message(Command("report"))
async def cmd_report(message: Message, bot: Bot, group=None):
    if not group:
        return
    if not message.reply_to_message:
        return await message.reply("❌ Ответь на сообщение и напиши /report [причина]")

    target = message.reply_to_message.from_user
    parts = (message.text or "").split(maxsplit=1)
    reason = parts[1] if len(parts) > 1 else "без причины"
    reporter = message.from_user

    from keyboards.inline import report_kb
    report_text = (
        f"🆘 <b>Жалоба от</b> {reporter.mention_html()}\n"
        f"<b>На пользователя:</b> {target.mention_html()}\n"
        f"<b>Причина:</b> {reason}"
    )

    # Send to log chat or to admins
    if group.log_chat_id:
        try:
            await bot.send_message(
                group.log_chat_id,
                report_text,
                parse_mode="HTML",
                reply_markup=report_kb(target.id, message.reply_to_message.message_id)
            )
        except Exception as e:
            log.warning(f"Could not send report to log chat: {e}")

    await message.reply("✅ Жалоба отправлена администраторам.", parse_mode="HTML")


@router.message(Command("myprofile"))
async def cmd_myprofile(message: Message, group=None):
    if not group:
        return
    member = await get_or_create_member(
        message.from_user.id, message.chat.id,
        message.from_user.username, message.from_user.full_name
    )
    shield = "🛡️ Активен" if member.pip_shield_active else "❌ Нет"
    text = (
        f"👤 <b>Профиль</b>\n\n"
        f"Имя: {message.from_user.mention_html()}\n"
        f"Предупреждений: <b>{member.warnings}/{group.max_warnings}</b>\n"
        f"Нарушений: <b>{member.violations_count}</b>\n"
        f"Сообщений: <b>{member.messages_count}</b>\n"
        f"Репутация: <b>⭐ {member.reputation}</b>\n"
        f"Pips: <b>💰 {member.pips}</b>\n"
        f"PipShield: {shield}"
    )
    await message.reply(text, parse_mode="HTML")
