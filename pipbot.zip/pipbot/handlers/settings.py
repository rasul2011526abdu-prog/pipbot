"""
Handler for settings that require text input (e.g. welcome message, rules, blacklist).
Uses FSM (Finite State Machine) to collect multi-step input.
"""
from aiogram import Router, F, Bot
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.filters import StateFilter, Command
from database import update_group, get_group
from filters.admin import IsAdminFilter
from keyboards.inline import settings_menu_kb, back_kb

router = Router()


class SettingsState(StatesGroup):
    waiting_welcome = State()
    waiting_farewell = State()
    waiting_rules = State()
    waiting_blacklist_add = State()
    waiting_whitelist_add = State()
    waiting_spam_interval = State()
    waiting_max_warnings = State()
    waiting_log_chat = State()


# ===== WELCOME =====

@router.callback_query(F.data == "settings_welcome")
async def cb_settings_welcome(callback: CallbackQuery, group=None):
    if not group:
        return await callback.answer("❌ Только для групп", show_alert=True)

    text = (
        f"👋 <b>Настройка приветствия</b>\n\n"
        f"Текущее:\n<i>{group.welcome_text}</i>\n\n"
        f"Переменные:\n"
        f"• <code>{{name}}</code> — упоминание участника\n\n"
        f"Отправь новое приветствие или /cancel для отмены."
    )
    await callback.message.edit_text(text, parse_mode="HTML")
    await callback.answer()

    # Store group_id in FSM
    # We need FSMContext — this is triggered via callback, so pass group_id differently
    # Instead: ask user to use /setwelcome command
    await callback.message.answer(
        "✏️ Введи новый текст приветствия (или /cancel):",
        reply_markup=back_kb("menu_settings")
    )


@router.callback_query(F.data == "settings_rules")
async def cb_settings_rules(callback: CallbackQuery, group=None):
    if not group:
        return await callback.answer("❌ Только для групп", show_alert=True)
    await callback.message.answer(
        f"📋 <b>Текущие правила:</b>\n<i>{group.rules_text}</i>\n\n"
        f"Используй команду <code>/setrules Текст правил</code> для изменения.",
        parse_mode="HTML",
        reply_markup=back_kb("menu_settings")
    )
    await callback.answer()


@router.callback_query(F.data == "settings_logs")
async def cb_settings_logs(callback: CallbackQuery, group=None):
    if not group:
        return await callback.answer("❌ Только для групп", show_alert=True)
    log_chat = f"<code>{group.log_chat_id}</code>" if group.log_chat_id else "Не задан"
    await callback.message.answer(
        f"📝 <b>Чат для логов:</b> {log_chat}\n\n"
        f"Используй <code>/setlogchat ID_чата</code> для изменения.",
        parse_mode="HTML",
        reply_markup=back_kb("menu_settings")
    )
    await callback.answer()


@router.callback_query(F.data == "settings_captcha")
async def cb_settings_captcha(callback: CallbackQuery, group=None):
    if not group:
        return await callback.answer("❌ Только для групп", show_alert=True)

    status = "✅ Включена" if group.captcha_enabled else "❌ Выключена"
    from aiogram.utils.keyboard import InlineKeyboardBuilder
    from aiogram.types import InlineKeyboardButton
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(
            text=f"Капча: {status}",
            callback_data="toggle_captcha"
        )
    )
    builder.row(InlineKeyboardButton(text="🔙 Назад", callback_data="menu_settings"))

    await callback.message.edit_text(
        f"🧩 <b>Настройки капчи</b>\n\n"
        f"Статус: {status}\n"
        f"Таймаут: {group.captcha_timeout} сек.\n\n"
        f"Используй <code>/setcaptchatimeout секунды</code> для изменения таймаута.",
        parse_mode="HTML",
        reply_markup=builder.as_markup()
    )
    await callback.answer()


@router.callback_query(F.data == "toggle_captcha")
async def cb_toggle_captcha(callback: CallbackQuery, group=None):
    if not group:
        return await callback.answer("❌ Только для групп", show_alert=True)
    await update_group(group.id, captcha_enabled=not group.captcha_enabled)
    new = not group.captcha_enabled
    await callback.answer(f"Капча {'включена ✅' if new else 'выключена ❌'}", show_alert=True)

    group = await get_group(group.id)
    status = "✅ Включена" if group.captcha_enabled else "❌ Выключена"
    from aiogram.utils.keyboard import InlineKeyboardBuilder
    from aiogram.types import InlineKeyboardButton
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text=f"Капча: {status}", callback_data="toggle_captcha"))
    builder.row(InlineKeyboardButton(text="🔙 Назад", callback_data="menu_settings"))
    await callback.message.edit_reply_markup(reply_markup=builder.as_markup())


@router.callback_query(F.data == "manage_blacklist")
async def cb_manage_blacklist(callback: CallbackQuery, group=None):
    if not group:
        return await callback.answer("❌ Только для групп", show_alert=True)
    words = group.custom_bad_words or []
    words_str = ", ".join(words) if words else "Список пуст"
    await callback.message.answer(
        f"🚫 <b>Чёрный список слов</b>\n\n"
        f"Текущий список:\n<code>{words_str}</code>\n\n"
        f"Команды:\n"
        f"• <code>/badword добавить слово</code>\n"
        f"• <code>/badword удалить слово</code>\n"
        f"• <code>/badword список</code>",
        parse_mode="HTML",
        reply_markup=back_kb("settings_moderation")
    )
    await callback.answer()


@router.callback_query(F.data == "manage_whitelist")
async def cb_manage_whitelist(callback: CallbackQuery, group=None):
    if not group:
        return await callback.answer("❌ Только для групп", show_alert=True)
    domains = group.allowed_domains or []
    domains_str = "\n".join(f"• {d}" for d in domains) if domains else "Список пуст"
    await callback.message.answer(
        f"🔗 <b>Белый список ссылок</b>\n\n"
        f"Разрешённые домены:\n{domains_str}\n\n"
        f"Команды:\n"
        f"• <code>/allowdomain домен</code> — добавить\n"
        f"• <code>/removedomain домен</code> — удалить",
        parse_mode="HTML",
        reply_markup=back_kb("settings_moderation")
    )
    await callback.answer()


# ===== TEXT COMMANDS FOR SETTINGS =====

@router.message(Command("setwelcome"), IsAdminFilter())
async def cmd_setwelcome(message: Message, group=None):
    if not group:
        return
    parts = message.text.split(maxsplit=1)
    if len(parts) < 2:
        return await message.reply("❌ Использование: /setwelcome Текст приветствия\nПеременная {name} — упоминание пользователя.")
    await update_group(group.id, welcome_text=parts[1])
    await message.reply(f"✅ Приветствие обновлено!\n\nПример:\n{parts[1].replace('{name}', message.from_user.mention_html())}",
                        parse_mode="HTML")


@router.message(Command("setfarewell"), IsAdminFilter())
async def cmd_setfarewell(message: Message, group=None):
    if not group:
        return
    parts = message.text.split(maxsplit=1)
    if len(parts) < 2:
        return await message.reply("❌ Использование: /setfarewell Текст прощания")
    await update_group(group.id, farewell_text=parts[1])
    await message.reply("✅ Прощание обновлено!")


@router.message(Command("setrules"), IsAdminFilter())
async def cmd_setrules(message: Message, group=None):
    if not group:
        return
    parts = message.text.split(maxsplit=1)
    if len(parts) < 2:
        return await message.reply("❌ Использование: /setrules Текст правил")
    await update_group(group.id, rules_text=parts[1])
    await message.reply("✅ Правила обновлены!")


@router.message(Command("setlogchat"), IsAdminFilter())
async def cmd_setlogchat(message: Message, group=None):
    if not group:
        return
    parts = message.text.split()
    if len(parts) < 2:
        return await message.reply("❌ Использование: /setlogchat -100XXXXXXXXX")
    try:
        chat_id = int(parts[1])
        await update_group(group.id, log_chat_id=chat_id)
        await message.reply(f"✅ Лог-чат установлен: {chat_id}")
    except ValueError:
        await message.reply("❌ Укажи числовой ID чата.")


@router.message(Command("badword"), IsAdminFilter())
async def cmd_badword(message: Message, group=None):
    if not group:
        return
    parts = message.text.split(maxsplit=2)
    if len(parts) < 2:
        return await message.reply("❌ /badword добавить|удалить|список [слово]")

    action = parts[1].lower()
    current = list(group.custom_bad_words or [])

    if action == "список":
        if current:
            await message.reply(f"🚫 Чёрный список:\n" + "\n".join(f"• {w}" for w in current))
        else:
            await message.reply("Список пуст.")

    elif action == "добавить" and len(parts) >= 3:
        word = parts[2].lower()
        if word not in current:
            current.append(word)
            await update_group(group.id, custom_bad_words=current)
        await message.reply(f"✅ Слово «{word}» добавлено в чёрный список.")

    elif action == "удалить" and len(parts) >= 3:
        word = parts[2].lower()
        if word in current:
            current.remove(word)
            await update_group(group.id, custom_bad_words=current)
            await message.reply(f"✅ Слово «{word}» удалено из чёрного списка.")
        else:
            await message.reply(f"❌ Слово «{word}» не найдено в списке.")


@router.message(Command("allowdomain"), IsAdminFilter())
async def cmd_allowdomain(message: Message, group=None):
    if not group:
        return
    parts = message.text.split()
    if len(parts) < 2:
        return await message.reply("❌ /allowdomain домен.com")
    domain = parts[1].lower().strip("/ ")
    domains = list(group.allowed_domains or [])
    if domain not in domains:
        domains.append(domain)
        await update_group(group.id, allowed_domains=domains)
    await message.reply(f"✅ Домен {domain} добавлен в белый список.")


@router.message(Command("removedomain"), IsAdminFilter())
async def cmd_removedomain(message: Message, group=None):
    if not group:
        return
    parts = message.text.split()
    if len(parts) < 2:
        return await message.reply("❌ /removedomain домен.com")
    domain = parts[1].lower().strip("/ ")
    domains = list(group.allowed_domains or [])
    if domain in domains:
        domains.remove(domain)
        await update_group(group.id, allowed_domains=domains)
        await message.reply(f"✅ Домен {domain} удалён из белого списка.")
    else:
        await message.reply(f"❌ Домен {domain} не найден в белом списке.")


# Fix missing import
