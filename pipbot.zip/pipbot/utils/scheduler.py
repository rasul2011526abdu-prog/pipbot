import asyncio
from datetime import datetime
from aiogram import Bot
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from sqlalchemy import select
from database import async_session, Group, Member
from database.crud import (
    get_violations_stats, get_violations_today, get_total_violations, get_top_active,
)
from utils.logger import log
from config import config


async def send_daily_report(bot: Bot):
    log.info("Running daily report task...")
    async with async_session() as session:
        result = await session.execute(
            select(Group).where(Group.daily_report_enabled == True, Group.report_chat_id.isnot(None))
        )
        groups = result.scalars().all()

    for group in groups:
        try:
            stats = await get_violations_stats(group.id)
            today = await get_violations_today(group.id)
            total = await get_total_violations(group.id)
            top_active = await get_top_active(group.id, limit=3)
            type_icons = {"swear": "🤬", "spam": "🔁", "links": "🔗", "caps": "📢", "mentions": "👥", "emoji": "😀"}
            lines = [
                f"📅 <b>Ежедневный отчёт — {datetime.utcnow().strftime('%d.%m.%Y')}</b>",
                f"Группа: <b>{group.title}</b>\n",
                f"Нарушений сегодня: <b>{today}</b>",
                f"Всего нарушений: <b>{total}</b>\n",
            ]
            if stats:
                lines.append("<b>По типам:</b>")
                for vtype, count in sorted(stats.items(), key=lambda x: -x[1]):
                    lines.append(f"  {type_icons.get(vtype, '▪️')} {vtype}: {count}")
            if top_active:
                lines.append("\n<b>🏆 Топ активных:</b>")
                for i, m in enumerate(top_active):
                    name = m.full_name or m.username or f"User{m.user_id}"
                    lines.append(f"  {'🥇🥈🥉'[i*2:i*2+2]} {name} — {m.messages_count} сообщений")
            await bot.send_message(group.report_chat_id, "\n".join(lines), parse_mode="HTML")
        except Exception as e:
            log.error(f"Failed daily report for {group.id}: {e}")


async def check_expired_mutes(bot: Bot):
    from utils.moderation import apply_unmute
    async with async_session() as session:
        result = await session.execute(
            select(Member).where(
                Member.is_muted == True,
                Member.mute_until.isnot(None),
                Member.mute_until < datetime.utcnow()
            )
        )
        expired = result.scalars().all()
    for member in expired:
        try:
            await apply_unmute(bot, member.group_id, member.user_id)
        except Exception as e:
            log.warning(f"Auto-unmute failed for {member.user_id}: {e}")


def setup_scheduler(bot: Bot) -> AsyncIOScheduler:
    scheduler = AsyncIOScheduler(timezone="UTC")
    try:
        hour, minute = config.daily_report_time.split(":")
        hour, minute = int(hour), int(minute)
    except Exception:
        hour, minute = 9, 0
    scheduler.add_job(send_daily_report, "cron", hour=hour, minute=minute, args=[bot], id="daily_report", replace_existing=True)
    scheduler.add_job(check_expired_mutes, "interval", minutes=5, args=[bot], id="check_mutes", replace_existing=True)
    return scheduler
