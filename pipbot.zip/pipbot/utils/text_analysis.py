"""
Bad words lists for multiple languages.
This is a minimal set — in production, expand or use an external library.
"""

# Russian bad words (common roots/stems for matching)
RU_BAD_WORDS = [
    "хуй", "хуе", "хуя", "пизд", "ёбан", "ебан", "еба", "ёба",
    "блять", "блят", "бля", "сука", "суки", "сукин", "пидор",
    "пиздец", "мудак", "мудил", "залуп", "ебать", "ёбать",
    "выблядок", "ублюдок", "шлюха", "шлюх", "блядь", "блядск",
    "наху", "нахуй", "похуй", "похер", "ёпт", "ёпта",
    "залупа", "залуп", "хуйн", "пиздн", "ебн",
]

# English bad words
EN_BAD_WORDS = [
    "fuck", "fuck", "fuk", "f*ck", "f**k",
    "shit", "sh1t", "sh!t",
    "bitch", "b1tch", "b!tch",
    "cunt", "c*nt",
    "ass", "asshole", "a**hole",
    "dick", "d!ck", "cock",
    "nigger", "nigga",
    "faggot", "fag",
    "whore", "wh0re",
    "bastard",
    "motherfucker", "mf",
]

# Ukrainian bad words
UA_BAD_WORDS = [
    "хуй", "піздa", "єбан", "суко", "блядь", "мудак",
    "курва", "їбан", "їбати",
]

# Kazakh bad words
KZ_BAD_WORDS = [
    "сика", "сиқа", "пизда", "қатын",
]

ALL_BAD_WORDS = set(RU_BAD_WORDS + EN_BAD_WORDS + UA_BAD_WORDS + KZ_BAD_WORDS)


def contains_bad_words(text: str, custom_words: list = None) -> bool:
    """Check if text contains bad words."""
    text_lower = text.lower()
    
    # Remove common obfuscation
    replacements = {
        "@": "a", "0": "o", "3": "e", "1": "i", "4": "a",
        "$": "s", "5": "s", "!": "i", "+": "t",
    }
    clean_text = text_lower
    for char, replacement in replacements.items():
        clean_text = clean_text.replace(char, replacement)
    
    word_list = ALL_BAD_WORDS.copy()
    if custom_words:
        word_list.update(w.lower() for w in custom_words)
    
    for bad_word in word_list:
        if bad_word in text_lower or bad_word in clean_text:
            return True
    
    return False


def contains_links(text: str) -> list:
    """Extract all URLs from text."""
    import re
    url_pattern = re.compile(
        r'(?:https?://|www\.|t\.me/|@\w+)'
        r'(?:[a-zA-Z0-9\-._~:/?#\[\]@!$&\'()*+,;=%]+)'
    )
    return url_pattern.findall(text)


def is_link_allowed(url: str, allowed_domains: list) -> bool:
    """Check if a URL is in the allowed domains list."""
    import re
    url_lower = url.lower().strip()
    for domain in allowed_domains:
        domain_lower = domain.lower().strip()
        if domain_lower in url_lower:
            return True
    return False


def count_caps_ratio(text: str) -> float:
    """Return ratio of uppercase letters to total letters."""
    letters = [c for c in text if c.isalpha()]
    if len(letters) < 5:
        return 0.0
    caps = sum(1 for c in letters if c.isupper())
    return caps / len(letters)


def count_mentions(text: str) -> int:
    """Count @mentions in text."""
    import re
    return len(re.findall(r'@\w+', text))


def count_emoji(text: str) -> int:
    """Count emoji in text."""
    import emoji as emoji_lib
    return len(emoji_lib.distinct_emoji_list(text))
