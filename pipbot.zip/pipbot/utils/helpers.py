from datetime import datetime, timedelta
from typing import Optional
from aiogram.types import User, ChatMember
from aiogram import Bot


def format_duration(seconds: int) -> str:
    """Format seconds into human-readable duration."""
    if seconds < 60:
        return f"{seconds} сек"
    elif seconds < 3600:
        return f"{seconds // 60} мин"
    elif seconds < 86400:
        return f"{seconds // 3600} ч"
    else:
        return f"{seconds // 86400} д"


def parse_duration(text: str) -> Optional[int]:
    """Parse duration string like '10m', '1h', '2d' into seconds."""
    if not text:
        return None
    text = text.lower().strip()
    multipliers = {"s": 1, "m": 60, "h": 3600, "d": 86400, "w": 604800}
    if text[-1] in multipliers:
        try:
            return int(text[:-1]) * multipliers[text[-1]]
        except ValueError:
            return None
    try:
        return int(text) * 60  # default: minutes
    except ValueError:
        return None


def user_mention(user: User) -> str:
    """Create a markdown mention for a user."""
    name = user.full_name or f"User {user.id}"
    return f"[{name}](tg://user?id={user.id})"


def user_mention_by_id(user_id: int, name: str) -> str:
    """Create a markdown mention by user id."""
    return f"[{name}](tg://user?id={user_id})"


async def is_admin(bot: Bot, chat_id: int, user_id: int) -> bool:
    """Check if user is admin in a chat."""
    try:
        member = await bot.get_chat_member(chat_id, user_id)
        return member.status in ("creator", "administrator")
    except Exception:
        return False


async def get_admin_level(bot: Bot, chat_id: int, user_id: int) -> int:
    """Get admin level: 0=user, 1=admin, 2=creator."""
    try:
        member = await bot.get_chat_member(chat_id, user_id)
        if member.status == "creator":
            return 2
        elif member.status == "administrator":
            return 1
        return 0
    except Exception:
        return 0


def escape_md(text: str) -> str:
    """Escape markdown special characters."""
    special_chars = r'_*[]()~`>#+-=|{}.!'
    for char in special_chars:
        text = text.replace(char, f'\\{char}')
    return text


def truncate(text: str, max_len: int = 100) -> str:
    """Truncate text to max_len characters."""
    if len(text) <= max_len:
        return text
    return text[:max_len - 3] + "..."


def format_datetime(dt: datetime) -> str:
    """Format datetime for display."""
    return dt.strftime("%d.%m.%Y %H:%M")
