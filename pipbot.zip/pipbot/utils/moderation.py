"""
Core moderation logic — used by the message handler.
Each check returns (violated: bool, reason: str).
"""
import asyncio
from datetime import datetime, timedelta
from aiogram import Bot
from aiogram.types import Message, ChatPermissions
from database import (
    get_or_create_member, update_member, add_warning,
    add_violation, add_mod_log, get_group,
)
from utils.text_analysis import (
    contains_bad_words, contains_links, is_link_allowed,
    count_caps_ratio, count_mentions, count_emoji,
)
from utils.helpers import format_duration, user_mention
from utils.logger import log


async def delete_and_warn(
    bot: Bot,
    message: Message,
    group,
    violation_type: str,
    reason: str,
    notify: bool = True,
):
    """Delete message, record violation, add warning, and apply punishment if needed."""
    user = message.from_user
    chat_id = message.chat.id

    # Delete the offending message
    try:
        await message.delete()
    except Exception as e:
        log.warning(f"Could not delete message: {e}")

    # Record violation in DB
    await add_violation(
        group_id=chat_id,
        user_id=user.id,
        violation_type=violation_type,
        message_text=message.text or message.caption,
        action_taken="delete",
    )

    # Add warning
    warnings = await add_warning(user_id=user.id, group_id=chat_id)

    # Send notification
    if notify:
        mention = user_mention(user)
        warn_msg = (
            f"⚠️ {mention}, {reason}\n"
            f"Предупреждения: {warnings}/{group.max_warnings}"
        )
        try:
            sent = await bot.send_message(chat_id, warn_msg, parse_mode="Markdown")
            # Auto-delete notification after 10 seconds
            asyncio.create_task(_auto_delete(bot, chat_id, sent.message_id, delay=10))
        except Exception as e:
            log.warning(f"Could not send warning message: {e}")

    # Apply punishment if warnings exceeded
    if warnings >= group.max_warnings:
        member = await get_or_create_member(user.id, chat_id)
        # Check pip shield
        if member.pip_shield_active:
            await update_member(user.id, chat_id, pip_shield_active=False)
            try:
                sent = await bot.send_message(
                    chat_id,
                    f"🛡️ {user_mention(user)}, твой PipShield спас тебя от наказания! Щит сломан.",
                    parse_mode="Markdown"
                )
                asyncio.create_task(_auto_delete(bot, chat_id, sent.message_id, delay=15))
            except Exception:
                pass
            return

        if group.warn_action == "ban":
            await apply_ban(bot, chat_id, user.id, group, reason="Превышен лимит предупреждений")
        else:
            await apply_mute(bot, chat_id, user.id, group,
                             duration=group.mute_duration,
                             reason="Превышен лимит предупреждений")
        # Reset warnings after punishment
        await update_member(user.id, chat_id, warnings=0)

    # Send to log chat
    await send_to_log_chat(bot, group, f"🚫 Нарушение [{violation_type}] от {user_mention(user)}: {reason}")


async def apply_mute(bot: Bot, chat_id: int, user_id: int, group,
                     duration: int = 3600, reason: str = ""):
    """Mute a user for `duration` seconds."""
    until = datetime.utcnow() + timedelta(seconds=duration)
    permissions = ChatPermissions(can_send_messages=False)
    try:
        await bot.restrict_chat_member(
            chat_id=chat_id,
            user_id=user_id,
            permissions=permissions,
            until_date=until,
        )
        await update_member(user_id, chat_id, is_muted=True, mute_until=until)
        log.info(f"Muted user {user_id} in {chat_id} for {format_duration(duration)}")
    except Exception as e:
        log.error(f"Could not mute user {user_id}: {e}")


async def apply_unmute(bot: Bot, chat_id: int, user_id: int):
    """Unmute a user."""
    permissions = ChatPermissions(
        can_send_messages=True,
        can_send_media_messages=True,
        can_send_other_messages=True,
        can_add_web_page_previews=True,
    )
    try:
        await bot.restrict_chat_member(chat_id=chat_id, user_id=user_id, permissions=permissions)
        await update_member(user_id, chat_id, is_muted=False, mute_until=None)
        log.info(f"Unmuted user {user_id} in {chat_id}")
    except Exception as e:
        log.error(f"Could not unmute user {user_id}: {e}")


async def apply_ban(bot: Bot, chat_id: int, user_id: int, group=None, reason: str = ""):
    """Ban a user from the chat."""
    try:
        await bot.ban_chat_member(chat_id=chat_id, user_id=user_id)
        await update_member(user_id, chat_id, is_banned=True)
        log.info(f"Banned user {user_id} from {chat_id}. Reason: {reason}")
    except Exception as e:
        log.error(f"Could not ban user {user_id}: {e}")


async def apply_unban(bot: Bot, chat_id: int, user_id: int):
    """Unban a user."""
    try:
        await bot.unban_chat_member(chat_id=chat_id, user_id=user_id, only_if_banned=True)
        await update_member(user_id, chat_id, is_banned=False)
        log.info(f"Unbanned user {user_id} from {chat_id}")
    except Exception as e:
        log.error(f"Could not unban user {user_id}: {e}")


async def check_message(bot: Bot, message: Message, group, is_spam: bool = False) -> bool:
    """
    Run all enabled moderation checks on a message.
    Returns True if message was deleted/actioned.
    """
    if not message.from_user:
        return False

    user = message.from_user
    text = message.text or message.caption or ""

    # Skip admins
    try:
        member_status = await bot.get_chat_member(message.chat.id, user.id)
        if member_status.status in ("creator", "administrator"):
            return False
    except Exception:
        pass

    # --- Anti-spam ---
    if is_spam and group.anti_spam_enabled:
        await delete_and_warn(
            bot, message, group,
            violation_type="spam",
            reason="слишком частые сообщения (флуд)"
        )
        return True

    if not text:
        return False

    # --- Anti-swear ---
    if group.anti_swear_enabled:
        custom_words = group.custom_bad_words or []
        if contains_bad_words(text, custom_words):
            await delete_and_warn(
                bot, message, group,
                violation_type="swear",
                reason="нецензурная лексика запрещена"
            )
            return True

    # --- Anti-links ---
    if group.anti_links_enabled:
        links = contains_links(text)
        if links:
            allowed_domains = group.allowed_domains or []
            for link in links:
                if not is_link_allowed(link, allowed_domains):
                    await delete_and_warn(
                        bot, message, group,
                        violation_type="links",
                        reason="ссылки запрещены в этой группе"
                    )
                    return True

    # --- Anti-caps ---
    if group.anti_caps_enabled:
        ratio = count_caps_ratio(text)
        if ratio >= group.caps_threshold:
            await delete_and_warn(
                bot, message, group,
                violation_type="caps",
                reason=f"слишком много заглавных букв ({int(ratio * 100)}%)"
            )
            return True

    # --- Anti-mentions ---
    if group.anti_mentions_enabled:
        mention_count = count_mentions(text)
        if mention_count > group.max_mentions:
            await delete_and_warn(
                bot, message, group,
                violation_type="mentions",
                reason=f"слишком много упоминаний ({mention_count})"
            )
            return True

    # --- Anti-emoji ---
    if group.anti_emoji_enabled:
        emoji_count = count_emoji(text)
        if emoji_count > group.max_emoji:
            await delete_and_warn(
                bot, message, group,
                violation_type="emoji",
                reason=f"слишком много эмодзи ({emoji_count})"
            )
            return True

    return False


async def send_to_log_chat(bot: Bot, group, text: str):
    """Send a log message to the group's log chat if configured."""
    if group and group.log_chat_id:
        try:
            await bot.send_message(
                group.log_chat_id,
                f"[{group.title}] {text}",
                parse_mode="Markdown"
            )
        except Exception as e:
            log.warning(f"Could not send to log chat {group.log_chat_id}: {e}")


async def _auto_delete(bot: Bot, chat_id: int, message_id: int, delay: int = 10):
    """Delete a message after `delay` seconds."""
    await asyncio.sleep(delay)
    try:
        await bot.delete_message(chat_id, message_id)
    except Exception:
        pass
