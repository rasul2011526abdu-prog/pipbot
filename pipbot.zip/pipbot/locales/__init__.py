from .ru import STRINGS as RU_STRINGS

LANGUAGES = {
    "ru": RU_STRINGS,
    "en": RU_STRINGS,  # fallback to RU until EN strings added
    "uk": RU_STRINGS,
    "kz": RU_STRINGS,
}


def t(key: str, lang: str = "ru", **kwargs) -> str:
    """Get translated string by key."""
    strings = LANGUAGES.get(lang, RU_STRINGS)
    text = strings.get(key, RU_STRINGS.get(key, key))
    if kwargs:
        try:
            text = text.format(**kwargs)
        except (KeyError, ValueError):
            pass
    return text
