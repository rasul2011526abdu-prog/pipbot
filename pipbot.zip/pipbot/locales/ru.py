"""Russian locale strings."""

STRINGS = {
    "welcome": "👋 Добро пожаловать, {name}!\nПрочитай /rules.",
    "farewell": "👋 {name} покинул(а) группу.",
    "captcha_prompt": (
        "👋 Привет, {name}!\n"
        "Для доступа в чат реши пример:\n\n"
        "🧮 <b>{question}</b>\n\n"
        "У тебя <b>{timeout} секунд</b>."
    ),
    "captcha_ok": "✅ Капча пройдена! Добро пожаловать.",
    "captcha_fail": "❌ Неверный ответ! Попробуй ещё раз.",
    "captcha_timeout": "⏰ Пользователь не прошёл капчу и был удалён.",
    "warn_issued": "⚠️ {name}, {reason}\nПредупреждений: {warns}/{max}",
    "mute_issued": "🔇 {name} замучен на {duration}. Причина: {reason}",
    "ban_issued": "🚫 {name} заблокирован. Причина: {reason}",
    "shield_saved": "🛡️ {name}, твой PipShield защитил тебя! Щит сломан.",
    "violation_swear": "нецензурная лексика запрещена",
    "violation_spam": "слишком частые сообщения (флуд)",
    "violation_links": "ссылки запрещены в этой группе",
    "violation_caps": "слишком много заглавных букв ({pct}%)",
    "violation_mentions": "слишком много упоминаний ({count})",
    "violation_emoji": "слишком много эмодзи ({count})",
}
