from sqlalchemy import select, update, func, desc
from sqlalchemy.ext.asyncio import AsyncSession
from datetime import datetime, timedelta
from typing import Optional, List
from .models import Group, Member, Violation, ModLog, CaptchaChallenge, async_session


# ===== GROUP =====

async def get_group(group_id: int) -> Optional[Group]:
    async with async_session() as session:
        result = await session.execute(select(Group).where(Group.id == group_id))
        return result.scalar_one_or_none()


async def get_or_create_group(group_id: int, title: str = "", username: str = None) -> Group:
    async with async_session() as session:
        result = await session.execute(select(Group).where(Group.id == group_id))
        group = result.scalar_one_or_none()
        if not group:
            group = Group(id=group_id, title=title, username=username)
            session.add(group)
            await session.commit()
            await session.refresh(group)
        elif title and group.title != title:
            group.title = title
            await session.commit()
        return group


async def update_group(group_id: int, **kwargs) -> bool:
    async with async_session() as session:
        await session.execute(
            update(Group).where(Group.id == group_id).values(**kwargs)
        )
        await session.commit()
        return True


# ===== MEMBER =====

async def get_member(user_id: int, group_id: int) -> Optional[Member]:
    async with async_session() as session:
        result = await session.execute(
            select(Member).where(Member.user_id == user_id, Member.group_id == group_id)
        )
        return result.scalar_one_or_none()


async def get_or_create_member(user_id: int, group_id: int,
                                username: str = None, full_name: str = None) -> Member:
    async with async_session() as session:
        result = await session.execute(
            select(Member).where(Member.user_id == user_id, Member.group_id == group_id)
        )
        member = result.scalar_one_or_none()
        if not member:
            member = Member(
                user_id=user_id, group_id=group_id,
                username=username, full_name=full_name
            )
            session.add(member)
            await session.commit()
            await session.refresh(member)
        else:
            changed = False
            if username and member.username != username:
                member.username = username
                changed = True
            if full_name and member.full_name != full_name:
                member.full_name = full_name
                changed = True
            if changed:
                await session.commit()
        return member


async def update_member(user_id: int, group_id: int, **kwargs) -> bool:
    async with async_session() as session:
        await session.execute(
            update(Member)
            .where(Member.user_id == user_id, Member.group_id == group_id)
            .values(**kwargs)
        )
        await session.commit()
        return True


async def add_warning(user_id: int, group_id: int) -> int:
    async with async_session() as session:
        result = await session.execute(
            select(Member).where(Member.user_id == user_id, Member.group_id == group_id)
        )
        member = result.scalar_one_or_none()
        if not member:
            return 0
        member.warnings += 1
        member.violations_count += 1
        member.reputation -= 1
        await session.commit()
        return member.warnings


async def remove_warning(user_id: int, group_id: int) -> int:
    async with async_session() as session:
        result = await session.execute(
            select(Member).where(Member.user_id == user_id, Member.group_id == group_id)
        )
        member = result.scalar_one_or_none()
        if not member:
            return 0
        member.warnings = max(0, member.warnings - 1)
        await session.commit()
        return member.warnings


async def increment_messages(user_id: int, group_id: int):
    async with async_session() as session:
        result = await session.execute(
            select(Member).where(Member.user_id == user_id, Member.group_id == group_id)
        )
        member = result.scalar_one_or_none()
        if member:
            member.messages_count += 1
            member.last_message_at = datetime.utcnow()
            member.pips += 1
            if member.messages_count % 10 == 0:
                member.reputation += 1
            await session.commit()


async def get_top_violators(group_id: int, limit: int = 10) -> List[Member]:
    async with async_session() as session:
        result = await session.execute(
            select(Member)
            .where(Member.group_id == group_id, Member.violations_count > 0)
            .order_by(desc(Member.violations_count))
            .limit(limit)
        )
        return list(result.scalars().all())


async def get_top_active(group_id: int, limit: int = 10) -> List[Member]:
    async with async_session() as session:
        result = await session.execute(
            select(Member)
            .where(Member.group_id == group_id)
            .order_by(desc(Member.messages_count))
            .limit(limit)
        )
        return list(result.scalars().all())


async def get_top_reputation(group_id: int, limit: int = 10) -> List[Member]:
    async with async_session() as session:
        result = await session.execute(
            select(Member)
            .where(Member.group_id == group_id)
            .order_by(desc(Member.reputation))
            .limit(limit)
        )
        return list(result.scalars().all())


# ===== VIOLATIONS =====

async def add_violation(group_id: int, user_id: int, violation_type: str,
                        message_text: str = None, action_taken: str = None):
    async with async_session() as session:
        violation = Violation(
            group_id=group_id, user_id=user_id,
            violation_type=violation_type,
            message_text=message_text[:500] if message_text else None,
            action_taken=action_taken
        )
        session.add(violation)
        await session.commit()


async def get_violations_stats(group_id: int) -> dict:
    async with async_session() as session:
        result = await session.execute(
            select(Violation.violation_type, func.count(Violation.id).label("count"))
            .where(Violation.group_id == group_id)
            .group_by(Violation.violation_type)
        )
        return {row.violation_type: row.count for row in result}


async def get_violations_today(group_id: int) -> int:
    async with async_session() as session:
        today = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
        result = await session.execute(
            select(func.count(Violation.id))
            .where(Violation.group_id == group_id, Violation.created_at >= today)
        )
        return result.scalar() or 0


async def get_total_violations(group_id: int) -> int:
    async with async_session() as session:
        result = await session.execute(
            select(func.count(Violation.id)).where(Violation.group_id == group_id)
        )
        return result.scalar() or 0


# ===== MOD LOGS =====

async def add_mod_log(group_id: int, admin_id: int, admin_name: str,
                      action: str, target_id: int = None,
                      target_name: str = None, reason: str = None):
    async with async_session() as session:
        log = ModLog(
            group_id=group_id, admin_id=admin_id, admin_name=admin_name,
            target_id=target_id, target_name=target_name,
            action=action, reason=reason
        )
        session.add(log)
        await session.commit()


async def get_recent_logs(group_id: int, limit: int = 20) -> List[ModLog]:
    async with async_session() as session:
        result = await session.execute(
            select(ModLog)
            .where(ModLog.group_id == group_id)
            .order_by(desc(ModLog.created_at))
            .limit(limit)
        )
        return list(result.scalars().all())


# ===== CAPTCHA =====

async def create_captcha(group_id: int, user_id: int, answer: str,
                         message_id: int, timeout: int = 60) -> CaptchaChallenge:
    async with async_session() as session:
        captcha = CaptchaChallenge(
            group_id=group_id, user_id=user_id, answer=answer,
            message_id=message_id,
            expires_at=datetime.utcnow() + timedelta(seconds=timeout)
        )
        session.add(captcha)
        await session.commit()
        await session.refresh(captcha)
        return captcha


async def get_captcha(group_id: int, user_id: int) -> Optional[CaptchaChallenge]:
    async with async_session() as session:
        result = await session.execute(
            select(CaptchaChallenge)
            .where(
                CaptchaChallenge.group_id == group_id,
                CaptchaChallenge.user_id == user_id,
                CaptchaChallenge.solved == False,
                CaptchaChallenge.expires_at > datetime.utcnow()
            )
            .order_by(desc(CaptchaChallenge.created_at))
        )
        return result.scalar_one_or_none()


async def solve_captcha(group_id: int, user_id: int) -> bool:
    async with async_session() as session:
        result = await session.execute(
            select(CaptchaChallenge)
            .where(
                CaptchaChallenge.group_id == group_id,
                CaptchaChallenge.user_id == user_id,
                CaptchaChallenge.solved == False
            )
        )
        captcha = result.scalar_one_or_none()
        if captcha:
            captcha.solved = True
            await session.commit()
            return True
        return False
