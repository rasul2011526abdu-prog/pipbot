from sqlalchemy import (
    Column, Integer, BigInteger, String, Boolean, DateTime, Float, Text, ForeignKey, JSON
)
from sqlalchemy.orm import DeclarativeBase, relationship
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from datetime import datetime
from config import config


class Base(DeclarativeBase):
    pass


engine = create_async_engine(config.database_url, echo=False)
async_session = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)


class Group(Base):
    __tablename__ = "groups"

    id = Column(BigInteger, primary_key=True)
    title = Column(String(255))
    username = Column(String(100), nullable=True)
    language = Column(String(10), default="ru")
    created_at = Column(DateTime, default=datetime.utcnow)

    # Anti-spam settings
    anti_spam_enabled = Column(Boolean, default=True)
    spam_interval = Column(Integer, default=3)

    # Anti-swear
    anti_swear_enabled = Column(Boolean, default=True)
    custom_bad_words = Column(JSON, default=list)

    # Anti-links
    anti_links_enabled = Column(Boolean, default=True)
    allowed_domains = Column(JSON, default=lambda: ["t.me", "youtube.com", "youtu.be", "telegra.ph"])

    # Anti-caps
    anti_caps_enabled = Column(Boolean, default=True)
    caps_threshold = Column(Float, default=0.7)

    # Anti-mentions
    anti_mentions_enabled = Column(Boolean, default=True)
    max_mentions = Column(Integer, default=5)

    # Anti-emoji
    anti_emoji_enabled = Column(Boolean, default=False)
    max_emoji = Column(Integer, default=10)

    # Warnings
    max_warnings = Column(Integer, default=3)
    warn_action = Column(String(20), default="mute")
    mute_duration = Column(Integer, default=3600)

    # Account age check
    check_account_age = Column(Boolean, default=False)
    min_account_age_days = Column(Integer, default=30)

    # Avatar check
    check_avatar = Column(Boolean, default=False)

    # Welcome
    welcome_enabled = Column(Boolean, default=True)
    welcome_text = Column(Text, default="👋 Добро пожаловать, {name}!\nПрочитай /rules.")
    welcome_buttons = Column(JSON, default=list)
    farewell_enabled = Column(Boolean, default=True)
    farewell_text = Column(Text, default="👋 {name} покинул(а) группу.")

    # Captcha
    captcha_enabled = Column(Boolean, default=True)
    captcha_timeout = Column(Integer, default=60)

    # Rules
    rules_text = Column(Text, default="Правила группы не установлены.")

    # Log chat
    log_chat_id = Column(BigInteger, nullable=True)

    # Daily reports
    daily_report_enabled = Column(Boolean, default=False)
    report_chat_id = Column(BigInteger, nullable=True)

    members = relationship("Member", back_populates="group", cascade="all, delete-orphan")
    violations = relationship("Violation", back_populates="group", cascade="all, delete-orphan")
    mod_logs = relationship("ModLog", back_populates="group", cascade="all, delete-orphan")


class Member(Base):
    __tablename__ = "members"

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger, nullable=False)
    group_id = Column(BigInteger, ForeignKey("groups.id"), nullable=False)
    username = Column(String(100), nullable=True)
    full_name = Column(String(255), nullable=True)
    warnings = Column(Integer, default=0)
    is_muted = Column(Boolean, default=False)
    mute_until = Column(DateTime, nullable=True)
    is_banned = Column(Boolean, default=False)
    reputation = Column(Integer, default=0)
    pips = Column(Integer, default=0)
    messages_count = Column(Integer, default=0)
    violations_count = Column(Integer, default=0)
    joined_at = Column(DateTime, default=datetime.utcnow)
    last_message_at = Column(DateTime, nullable=True)
    pip_shield_active = Column(Boolean, default=False)
    admin_level = Column(Integer, default=0)  # 0=user,1=observer,2=moderator,3=admin

    group = relationship("Group", back_populates="members")


class Violation(Base):
    __tablename__ = "violations"

    id = Column(Integer, primary_key=True, autoincrement=True)
    group_id = Column(BigInteger, ForeignKey("groups.id"), nullable=False)
    user_id = Column(BigInteger, nullable=False)
    violation_type = Column(String(50), nullable=False)
    message_text = Column(Text, nullable=True)
    action_taken = Column(String(50), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    group = relationship("Group", back_populates="violations")


class ModLog(Base):
    __tablename__ = "mod_logs"

    id = Column(Integer, primary_key=True, autoincrement=True)
    group_id = Column(BigInteger, ForeignKey("groups.id"), nullable=False)
    admin_id = Column(BigInteger, nullable=False)
    admin_name = Column(String(255), nullable=True)
    target_id = Column(BigInteger, nullable=True)
    target_name = Column(String(255), nullable=True)
    action = Column(String(50), nullable=False)
    reason = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    group = relationship("Group", back_populates="mod_logs")


class CaptchaChallenge(Base):
    __tablename__ = "captcha_challenges"

    id = Column(Integer, primary_key=True, autoincrement=True)
    group_id = Column(BigInteger, nullable=False)
    user_id = Column(BigInteger, nullable=False)
    answer = Column(String(20), nullable=False)
    message_id = Column(Integer, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    expires_at = Column(DateTime, nullable=False)
    solved = Column(Boolean, default=False)


async def init_db():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
