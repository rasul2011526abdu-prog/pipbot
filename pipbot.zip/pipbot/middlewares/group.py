from typing import Callable, Dict, Any, Awaitable
from aiogram import BaseMiddleware
from aiogram.types import Message, CallbackQuery, TelegramObject
from database import get_or_create_group


class GroupMiddleware(BaseMiddleware):
    async def __call__(self, handler, event, data):
        chat = None
        if isinstance(event, Message) and event.chat.type != "private":
            chat = event.chat
        elif isinstance(event, CallbackQuery) and event.message and event.message.chat.type != "private":
            chat = event.message.chat

        if chat:
            group = await get_or_create_group(chat.id, title=chat.title or "", username=chat.username)
            data["group"] = group
        else:
            data["group"] = None

        return await handler(event, data)
