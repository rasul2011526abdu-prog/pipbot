from typing import Callable, Dict, Any, Awaitable
from aiogram import BaseMiddleware
from aiogram.types import Message, TelegramObject
from datetime import datetime, timedelta
import asyncio


class AntiSpamMiddleware(BaseMiddleware):
    """Track last message time per user per chat to prevent flooding."""

    def __init__(self):
        self._last_message: Dict[str, datetime] = {}
        self._locks: Dict[str, asyncio.Lock] = {}

    async def __call__(
        self,
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any],
    ) -> Any:
        if not isinstance(event, Message):
            return await handler(event, data)

        if event.chat.type == "private":
            return await handler(event, data)

        group = data.get("group")
        if not group or not group.anti_spam_enabled:
            return await handler(event, data)

        user_id = event.from_user.id
        chat_id = event.chat.id
        key = f"{chat_id}:{user_id}"

        now = datetime.utcnow()
        last = self._last_message.get(key)

        if last:
            diff = (now - last).total_seconds()
            if diff < group.spam_interval:
                data["is_spam"] = True
            else:
                data["is_spam"] = False
        else:
            data["is_spam"] = False

        self._last_message[key] = now
        return await handler(event, data)
