from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder


def main_menu_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="📖 Инструкция", callback_data="menu_help"),
        InlineKeyboardButton(text="⚙️ Настройки", callback_data="menu_settings"),
    )
    builder.row(
        InlineKeyboardButton(text="📊 Статистика", callback_data="menu_stats"),
        InlineKeyboardButton(text="🆘 Поддержка", callback_data="menu_support"),
    )
    builder.row(
        InlineKeyboardButton(text="ℹ️ Информация", callback_data="menu_info"),
        InlineKeyboardButton(text="🌐 Язык", callback_data="menu_language"),
    )
    return builder.as_markup()


def settings_menu_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="🛡️ Защита", callback_data="settings_protection"),
        InlineKeyboardButton(text="👮 Модерация", callback_data="settings_moderation"),
    )
    builder.row(
        InlineKeyboardButton(text="👋 Приветствие", callback_data="settings_welcome"),
        InlineKeyboardButton(text="🧩 Капча", callback_data="settings_captcha"),
    )
    builder.row(
        InlineKeyboardButton(text="📋 Правила", callback_data="settings_rules"),
        InlineKeyboardButton(text="📝 Логи", callback_data="settings_logs"),
    )
    builder.row(
        InlineKeyboardButton(text="🔙 Назад", callback_data="menu_back"),
    )
    return builder.as_markup()


def protection_settings_kb(group) -> InlineKeyboardMarkup:
    """Build protection settings keyboard with current on/off state."""
    def toggle(val): return "✅" if val else "❌"

    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(
            text=f"{toggle(group.anti_swear_enabled)} Антимат",
            callback_data="toggle_anti_swear"
        ),
        InlineKeyboardButton(
            text=f"{toggle(group.anti_spam_enabled)} Антиспам",
            callback_data="toggle_anti_spam"
        ),
    )
    builder.row(
        InlineKeyboardButton(
            text=f"{toggle(group.anti_links_enabled)} Антиссылки",
            callback_data="toggle_anti_links"
        ),
        InlineKeyboardButton(
            text=f"{toggle(group.anti_caps_enabled)} Антикапс",
            callback_data="toggle_anti_caps"
        ),
    )
    builder.row(
        InlineKeyboardButton(
            text=f"{toggle(group.anti_mentions_enabled)} Антиупоминания",
            callback_data="toggle_anti_mentions"
        ),
        InlineKeyboardButton(
            text=f"{toggle(group.anti_emoji_enabled)} Антиэмодзи",
            callback_data="toggle_anti_emoji"
        ),
    )
    builder.row(
        InlineKeyboardButton(text="🔙 Назад", callback_data="menu_settings"),
    )
    return builder.as_markup()


def moderation_settings_kb(group) -> InlineKeyboardMarkup:
    def toggle(val): return "✅" if val else "❌"

    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(
            text=f"⚠️ Лимит предупреждений: {group.max_warnings}",
            callback_data="set_max_warnings"
        ),
    )
    builder.row(
        InlineKeyboardButton(
            text=f"🔇 Действие: {'Мут' if group.warn_action == 'mute' else 'Бан'}",
            callback_data="toggle_warn_action"
        ),
    )
    builder.row(
        InlineKeyboardButton(
            text=f"{toggle(group.check_account_age)} Проверка возраста",
            callback_data="toggle_account_age"
        ),
        InlineKeyboardButton(
            text=f"{toggle(group.check_avatar)} Проверка аватара",
            callback_data="toggle_avatar_check"
        ),
    )
    builder.row(
        InlineKeyboardButton(text="🚫 Чёрный список слов", callback_data="manage_blacklist"),
    )
    builder.row(
        InlineKeyboardButton(text="🔗 Белый список ссылок", callback_data="manage_whitelist"),
    )
    builder.row(
        InlineKeyboardButton(text="🔙 Назад", callback_data="menu_settings"),
    )
    return builder.as_markup()


def stats_menu_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="📊 Статистика нарушений", callback_data="stats_violations"),
        InlineKeyboardButton(text="👑 Топ нарушителей", callback_data="stats_violators"),
    )
    builder.row(
        InlineKeyboardButton(text="🏆 Топ активных", callback_data="stats_active"),
        InlineKeyboardButton(text="⭐ Топ репутации", callback_data="stats_reputation"),
    )
    builder.row(
        InlineKeyboardButton(text="📁 Экспорт CSV", callback_data="stats_export"),
    )
    builder.row(
        InlineKeyboardButton(text="🔙 Назад", callback_data="menu_back"),
    )
    return builder.as_markup()


def language_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="🇷🇺 Русский", callback_data="lang_ru"),
        InlineKeyboardButton(text="🇺🇦 Українська", callback_data="lang_uk"),
    )
    builder.row(
        InlineKeyboardButton(text="🇬🇧 English", callback_data="lang_en"),
        InlineKeyboardButton(text="🇰🇿 Қазақша", callback_data="lang_kz"),
    )
    builder.row(
        InlineKeyboardButton(text="🔙 Назад", callback_data="menu_back"),
    )
    return builder.as_markup()


def captcha_kb(answer: str, wrong_answers: list) -> InlineKeyboardMarkup:
    """Build captcha keyboard with answer buttons."""
    import random
    options = wrong_answers + [answer]
    random.shuffle(options)
    builder = InlineKeyboardBuilder()
    for option in options:
        builder.button(
            text=str(option),
            callback_data=f"captcha_{option}"
        )
    builder.adjust(len(options))
    return builder.as_markup()


def report_kb(reported_user_id: int, message_id: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(
            text="⚠️ Предупредить",
            callback_data=f"report_warn_{reported_user_id}_{message_id}"
        ),
        InlineKeyboardButton(
            text="🔇 Замутить",
            callback_data=f"report_mute_{reported_user_id}_{message_id}"
        ),
    )
    builder.row(
        InlineKeyboardButton(
            text="🚫 Забанить",
            callback_data=f"report_ban_{reported_user_id}_{message_id}"
        ),
        InlineKeyboardButton(
            text="❌ Отклонить",
            callback_data=f"report_dismiss_{reported_user_id}_{message_id}"
        ),
    )
    return builder.as_markup()


def back_kb(callback: str = "menu_back") -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="🔙 Назад", callback_data=callback)
    return builder.as_markup()


def confirm_kb(action: str) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="✅ Да", callback_data=f"confirm_{action}"),
        InlineKeyboardButton(text="❌ Отмена", callback_data="cancel"),
    )
    return builder.as_markup()


def pip_shop_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="🛡️ Защита от мута (50 Pips)", callback_data="shop_shield"),
        InlineKeyboardButton(text="⭐ +1 Репутация (30 Pips)", callback_data="shop_rep"),
    )
    builder.row(
        InlineKeyboardButton(text="🔙 Назад", callback_data="menu_back"),
    )
    return builder.as_markup()
