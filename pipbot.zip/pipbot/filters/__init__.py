from aiogram.filters import BaseFilter
from aiogram.types import Message, CallbackQuery
from aiogram import Bot
from config import config


class IsAdminFilter(BaseFilter):
    async def __call__(self, event, bot: Bot) -> bool:
        if isinstance(event, CallbackQuery):
            msg = event.message
            user_id = event.from_user.id
        else:
            msg = event
            user_id = event.from_user.id

        if user_id in config.super_admins:
            return True
        if not msg or msg.chat.type == "private":
            return False
        try:
            member = await bot.get_chat_member(msg.chat.id, user_id)
            return member.status in ("creator", "administrator")
        except Exception:
            return False


class IsSuperAdminFilter(BaseFilter):
    async def __call__(self, event) -> bool:
        user_id = getattr(event.from_user, "id", None)
        return user_id in config.super_admins


class IsGroupFilter(BaseFilter):
    async def __call__(self, event: Message) -> bool:
        return event.chat.type in ("group", "supergroup")


class IsPrivateFilter(BaseFilter):
    async def __call__(self, event: Message) -> bool:
        return event.chat.type == "private"
