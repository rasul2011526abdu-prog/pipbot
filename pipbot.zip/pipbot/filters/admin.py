from aiogram.filters import BaseFilter
from aiogram.types import Message, CallbackQuery
from aiogram import Bot
from config import config


class IsAdminFilter(BaseFilter):
    """Passes if the user is a chat admin or super admin."""

    async def __call__(self, event: Message | CallbackQuery, bot: Bot) -> bool:
        if isinstance(event, CallbackQuery):
            user_id = event.from_user.id
            chat_id = event.message.chat.id if event.message else None
        else:
            user_id = event.from_user.id
            chat_id = event.chat.id

        if user_id in config.super_admins:
            return True

        if not chat_id:
            return False

        try:
            member = await bot.get_chat_member(chat_id, user_id)
            return member.status in ("creator", "administrator")
        except Exception:
            return False


class IsSuperAdminFilter(BaseFilter):
    """Passes only for super admins defined in .env."""

    async def __call__(self, event: Message | CallbackQuery) -> bool:
        user_id = event.from_user.id
        return user_id in config.super_admins


class IsGroupFilter(BaseFilter):
    """Passes only for group/supergroup chats."""

    async def __call__(self, event: Message) -> bool:
        return event.chat.type in ("group", "supergroup")


class IsPrivateFilter(BaseFilter):
    """Passes only for private chats."""

    async def __call__(self, event: Message) -> bool:
        return event.chat.type == "private"
